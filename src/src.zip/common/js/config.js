// export const HOST = 'http://zjn225.cn:3000'
export const HOST = 'http://120.79.162.149:3000'
//export const HOST = 'http://127.0.0.1:3000'

export const ERR_OK = 200

export const playMode = {
  sequence: 0,
  loop: 1,
  random: 2
}
