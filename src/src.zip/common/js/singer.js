export default class Singer {
  constructor ({id, name, avatar, aliaName}) {
    this.id = id
    this.name = name
    this.avatar = avatar
    this.aliaName = aliaName
  }
}
